import Layout from '../../Components/Layout'

function SignIn() {
  return (
    <Layout>
      SignIn
    </Layout>
  )
}

export default SignIn