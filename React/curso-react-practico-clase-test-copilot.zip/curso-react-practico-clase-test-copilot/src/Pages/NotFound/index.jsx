import Layout from '../../Components/Layout'

function NotFound() {
  return (
    <Layout>
      NotFound
    </Layout>
  )
}

export default NotFound