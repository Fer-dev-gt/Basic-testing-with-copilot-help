import Layout from '../../Components/Layout'

function MyAccount() {
  return (
    <Layout>
      MyAccount
    </Layout>
  )
}

export default MyAccount